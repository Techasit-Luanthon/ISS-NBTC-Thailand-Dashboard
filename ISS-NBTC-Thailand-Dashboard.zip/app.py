from flask import Flask, render_template
import requests

app = Flask(__name__)
ISS_API = "https://api.wheretheiss.at/v1/satellites/25544"

@app.get("/")
def home():
    iss = None
    error = None
    try:
        response = requests.get(ISS_API, timeout=8)
        response.raise_for_status()
        data = response.json()
        iss = {
            "latitude": round(float(data["latitude"]), 4),
            "longitude": round(float(data["longitude"]), 4),
            "altitude_km": round(float(data["altitude"]), 2),
            "velocity_kmh": round(float(data["velocity"]), 2),
            "timestamp": data.get("timestamp"),
        }
    except (requests.RequestException, KeyError, TypeError, ValueError):
        error = "ISS data is temporarily unavailable. Please refresh later."

    return render_template("index.html", iss=iss, error=error)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
