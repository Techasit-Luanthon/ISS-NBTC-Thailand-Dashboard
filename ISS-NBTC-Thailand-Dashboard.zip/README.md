# ISS–NBTC Thailand Educational Dashboard

A safe, read-only educational dashboard that combines:
- Current International Space Station (ISS) position from the public Open Notify-compatible endpoint `https://api.wheretheiss.at/v1/satellites/25544`
- A reference link to Thailand's National Broadcasting and Telecommunications Commission (NBTC): https://www.nbtc.go.th/
- A simple Thailand-focused information panel explaining that NBTC is Thailand's telecom/broadcasting regulator.

**Important:** This is not an official NBTC project and does not connect to, control, scan, or monitor NBTC infrastructure, licensed networks, satellites, or radio spectrum. It only reads public ISS position data and links to public NBTC information. No credentials are needed.

## Requirements
- Python 3.10+
- Internet connection
- VS Code (recommended)

## Run locally
```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
python app.py
```
Open the local URL printed in the terminal (normally http://127.0.0.1:5000).

## Project structure
```text
ISS_NBTC_Thailand_Project/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
└── templates/
    └── index.html
```

## Data source
The app requests public ISS location data from Where the ISS at:
`https://api.wheretheiss.at/v1/satellites/25544`

If the service is unavailable, the page displays an error message rather than inventing a location.

## GitHub upload
1. Sign in to https://github.com/
2. Select **New repository**.
3. Name it `ISS-NBTC-Thailand-Dashboard`.
4. Choose **Public** or **Private**, then select **Create repository**.
5. Extract this ZIP file on your computer.
6. In the new GitHub repository, select **Add file → Upload files**.
7. Drag the *contents* of the extracted project folder into the upload area.
8. Enter commit message `Add ISS NBTC Thailand dashboard`.
9. Select **Commit changes**.

Alternative using Git:
```bash
git init
git add .
git commit -m "Add ISS NBTC Thailand dashboard"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/ISS-NBTC-Thailand-Dashboard.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username. Never put passwords, personal access tokens, or API secrets in source files.

## How to apply / extend
- Fork the repository if you want to build on another person's project.
- For an official NBTC collaboration, first contact NBTC through its official website and request written approval, an appropriate data source/API, and a named technical contact.
- Only add data feeds that are explicitly public and authorized. Keep the dashboard read-only.

## Disclaimer
Independent educational prototype. Not affiliated with or endorsed by NBTC, NASA, or the ISS program. ISS position data may be delayed or temporarily unavailable.
